Multiple-choices Benchmark data: collected from MMLU & GPQA

