4 Over(Under) Estimation Across Task Difficulty
Method: AFCE 10 questions, AFCE 1 question, top-k, vanilla, quiz-like 10 questions, sampling, probability(only for llama3-70b-8192)


