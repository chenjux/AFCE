Experiments: Bias in Confidence Estimation Across Demographic Personas
Method: AFCE 10 questions/ prompt setting

